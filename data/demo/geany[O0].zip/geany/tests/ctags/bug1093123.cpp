#include <iostream>

int main() {
using namespace std;
cout << 0 << endl;
int m;
}
