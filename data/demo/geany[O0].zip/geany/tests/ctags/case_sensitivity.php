<?php
// PHP is case insensitive about keywords

class A {}

CLASS B {}

Class C {}

ClAsS D {}



function a() {}

FUNCTION b() {}

Function c() {}

FuNcTiOn d() {}



trait tA {}

TRAIT tB {}

Trait tC {}

TrAiT tD {}



interface iA {}

INTERFACE iB {}

Interface iC {}

InTeRfAcE iD {}
