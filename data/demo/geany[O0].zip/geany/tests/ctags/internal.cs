// Assembly1.cs
// compile with: /target:library
internal class BaseClass 
{
   public static int IntM = 0;
}
