namespace {
	void anon_f() { }
}

namespace a {
	void a_f() { }
	namespace b {
		void a_b_f() { }
	}
}
