
var o = {
  aa: function () {
    foo: {
      return ;
    }
  },
  
  bb: function (a) {
    switch (a) {
      case 1:
        if (1) {
          return 32
        }
        break;
      case 2:
        return 31;
    }
    return 1;
  },
  
  cc: function() {}
};
