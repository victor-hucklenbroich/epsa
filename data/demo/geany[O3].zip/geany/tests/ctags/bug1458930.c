// test with --c-kinds=+p
char x();
wchar_t y();
