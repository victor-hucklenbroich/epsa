FUNCSTS func1(ENTSEQNO(seq)) {}
FUNCSTS func2 (MEMTXT(form_msg), MEMTXT (text), MEMTXT (mail)) {}
