#!/usr/bin/python

def main():
	# A broken ctags will see a function "initely_not_a_function" here.
	definitely_not_a_function = 0
	return

if __name__ == 'main':
	main()
