#!/usr/bin/end nodejs

function f(){}
