class Testclass():
    def main(self):
        variable = True

if __name__ == "__main__":
    module_level_attribute = True
