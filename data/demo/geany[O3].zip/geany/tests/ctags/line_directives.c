/* ANSI format */
# line 10 "a.c"
int a;
/* GNU C format */
# 20 "b.c"
int b;
/* obsolete format */
# 30 c.c
int c;
/* invalid formats */
# 1 OK
# 0 Not OK
