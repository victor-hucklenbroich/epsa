std::string & f1() {}
const std::string & f2() {}
std::string const & f3() {}
