include_file = '''
class (b)
'''

# dummy class to generate a tag
class dummy:
    pass
