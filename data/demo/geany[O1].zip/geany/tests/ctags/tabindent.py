def find_heading(self, position=0, direction=Direction.FORWARD, \
		heading=Heading, connect_with_document=True):
	pass
