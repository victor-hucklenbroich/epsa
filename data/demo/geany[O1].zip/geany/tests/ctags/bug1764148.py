#!/usr/bin/python
def PyFunc(msg): print msg
