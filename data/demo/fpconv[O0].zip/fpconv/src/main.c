#include <stdio.h>
#include "fpconv_dtoa.h"

int main() {
    char dest[24];
    double num = 12345.6789;
    int len = fpconv_dtoa(num, dest);
    dest[len] = '\0';  // Null-terminate the string
    printf("Converted number: %s\n", dest);
    return 0;
}
